clear
global delta
global b
delta=uint8(16);
b=uint8(2);
lena=imread("lena.jpg");% 512*512
flag=imread("flag.jpg");% 512*80
for i=1:80
    for j=1:512
        if(flag(i,j)<200)
            flag(i,j)=0;
        else
            flag(i,j)=1;
        end
    end
end
watermarked_lena=reshape(Embed(reshape(lena,1,[]),reshape(flag,1,[])),512,512);
imwrite(watermarked_lena,"watermarked_lena.jpg");
function m=Embed(p,s)
    global delta;
    global b;
    m=p;
    for i=1:length(s)
        m(i)=uint8((p(i)+delta*s(i))/(b*delta))*b*delta+s(i)*delta;
    end
end